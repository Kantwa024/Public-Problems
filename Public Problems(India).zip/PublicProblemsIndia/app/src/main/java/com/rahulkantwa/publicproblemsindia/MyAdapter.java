package com.rahulkantwa.publicproblemsindia;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Adapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

class LoadingViewHolder extends RecyclerView.ViewHolder
{
    public ProgressBar progressBar;
    public LoadingViewHolder(@NonNull View itemView) {
        super(itemView);
        progressBar = (ProgressBar)itemView.findViewById(R.id.progress_bar_result_comment_2);
    }
}

class ItemViewHolder extends RecyclerView.ViewHolder
{
    public TextView username,time,like,comment,problem;
    public ImageButton likebutton,commentbutton;
    public CircleImageView userimage;
    public ImageView problemimage;
    public ItemViewHolder(@NonNull View itemView) {
        super(itemView);
                username = itemView.findViewById(R.id.problem_user_name);
                time = itemView.findViewById(R.id.problem_time);
                like = itemView.findViewById(R.id.problem_likes);
                comment = itemView.findViewById(R.id.comments_count);
                problem = itemView.findViewById(R.id.problem);
                likebutton = itemView.findViewById(R.id.thumb_up);
                commentbutton = itemView.findViewById(R.id.problem_comment);
                userimage = itemView.findViewById(R.id.problem_user_profile);
                problemimage = itemView.findViewById(R.id.problem_image);
    }
}

public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int VIEW_TYPE_ITEM=0,VIEW_TYPE_LOADING=1;
    ILoadMore loadMore;
    boolean isLoading;
    Activity activity;
    List<ProblemData> items;
    int visibleThresold=5;
    int lastVisibleItem,totalItemCount;
    private ArrayList<String> Ids;
    private ArrayList<String> LikeStatement;
    private String mainID;


    public MyAdapter(RecyclerView recyclerView, Activity activity, List<ProblemData> items,ArrayList<String> Ids,ArrayList<String> LikeStatement,String mainID)
    {
        this.activity = activity;
        this.items = items;
        this.Ids = Ids;
        this.LikeStatement = LikeStatement;
        this.mainID = mainID;

        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager)recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if(!isLoading && totalItemCount <= (lastVisibleItem + visibleThresold))
                {
                    if(loadMore != null)
                    {
                        loadMore.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    @Override
    public int getItemViewType(int position) {
        return  items.get(position) == null?VIEW_TYPE_LOADING:VIEW_TYPE_ITEM;
    }

    public void setLoadMore(ILoadMore loadMore) {
        this.loadMore = loadMore;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType == VIEW_TYPE_ITEM)
        {
            View view = LayoutInflater.from(activity)
                    .inflate(R.layout.problemlayout,parent,false);
            return new ItemViewHolder(view);
        }
        else if(viewType == VIEW_TYPE_LOADING)
        {
            View view = LayoutInflater.from(activity)
                    .inflate(R.layout.progress_bar,parent,false);
            return new LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof ItemViewHolder)
        {
            ProblemData problemData = items.get(position);
            final ItemViewHolder viewHolder = (ItemViewHolder)holder;
            viewHolder.problem.setText(problemData.getProblem());
            viewHolder.like.setText(problemData.getLikes());
            viewHolder.comment.setText(problemData.getComments());
            Glide.with(activity)
                    .load(Uri.parse(problemData.getUserurl()))
                    .into(viewHolder.userimage);
            viewHolder.userimage.setEnabled(false);
            Glide.with(activity)
                    .load(Uri.parse(problemData.getImageurl()))
                    .into(viewHolder.problemimage);
            viewHolder.problemimage.setEnabled(false);
            viewHolder.username.setText(problemData.getUsername());
            if(LikeStatement.get(position).equalsIgnoreCase("yes"))
            {
                viewHolder.likebutton.setBackgroundResource(R.drawable.ic_thumb_up_yes_black_24dp);
            }
            else
            {
                viewHolder.likebutton.setBackgroundResource(R.drawable.ic_thumb_up_black_24dp);
            }
            viewHolder.likebutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(LikeStatement.get(position).equalsIgnoreCase("yes"))
                    {
                        viewHolder.likebutton.setBackgroundResource(R.drawable.ic_thumb_up_black_24dp);
                        LikeStatement.set(position,"no");
                        FirebaseDatabase.getInstance().getReference("Likes")
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .child(Ids.get(position))
                                .removeValue()
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        LikeStatement.set(position,"yes");
                                        viewHolder.likebutton.setBackgroundResource(R.drawable.ic_thumb_up_yes_black_24dp);
                                    }
                                });
                    }
                    else
                    {
                        LikeStatement.set(position,"yes");
                        viewHolder.likebutton.setBackgroundResource(R.drawable.ic_thumb_up_yes_black_24dp);
                        FirebaseDatabase.getInstance().getReference("Likes")
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .child(Ids.get(position))
                                .setValue("yes")
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        LikeStatement.set(position,"no");
                                        viewHolder.likebutton.setBackgroundResource(R.drawable.ic_thumb_up_black_24dp);
                                    }
                                });
                    }
                }
            });
            viewHolder.commentbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(activity.getApplicationContext(),CommentActivity.class);
                    intent.putExtra("mainId",mainID);
                    intent.putExtra("Id",Ids.get(position));
                    activity.startActivity(intent);
                }
            });

            long time = Long.parseLong(problemData.getTime());
            long systime = System.currentTimeMillis();
            long sec = (systime-time)/1000;
            if(sec < 60)
            {
                viewHolder.time.setText("Just now");
            }
            else if(sec/(60*60) < 1)
            {
                viewHolder.time.setText(sec/60+"m");
            }
            else if(sec/(60*60*24) < 1)
            {
                viewHolder.time.setText(sec/(60*60)+"h");
            }
            else
            {
                viewHolder.time.setText(sec/(60*60*24)+"d");
            }
        }
        else if(holder instanceof LoadingViewHolder)
        {
            LoadingViewHolder loadingViewHolder = (LoadingViewHolder)holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }
    }
    @Override
    public int getItemCount() {
        return items.size();
    }

    public void setLoaded() {
        isLoading = false;
    }

}