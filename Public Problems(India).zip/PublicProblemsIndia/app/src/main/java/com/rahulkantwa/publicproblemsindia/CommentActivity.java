package com.rahulkantwa.publicproblemsindia;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CommentActivity extends AppCompatActivity {
    private String mainId = "",Id = "";
    private ImageView offimage,onimage;
    private EditText editText;
    private RecyclerView recyclerView;
    private List<CommentData> items = new ArrayList<>();
    private CommentsAdapter commentsAdapter;
    private int totalcomments;
    private ArrayList<String> Ids = new ArrayList<>();
    private String Name,Url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);

        recyclerView = (RecyclerView)findViewById(R.id.comment_problem);
        offimage = (ImageView)findViewById(R.id.image_off);
        onimage = (ImageView)findViewById(R.id.image_on);
        editText = (EditText)findViewById(R.id.text_password);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().length() != 0)
                {
                    offimage.setVisibility(View.GONE);
                    onimage.setVisibility(View.VISIBLE);
                }
                else
                {
                    offimage.setVisibility(View.VISIBLE);
                    onimage.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        try {
            Intent intent = getIntent();
            mainId = intent.getStringExtra("mainId");
            Id = intent.getStringExtra("Id");
            LoadData();
            commentsAdapter = new CommentsAdapter(recyclerView,this,items);
            recyclerView.setAdapter(commentsAdapter);

            onimage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CommentData commentData = new CommentData();
                    commentData.setComment(editText.getText().toString().trim());
                    editText.setText("");
                    commentData.setUrl(Url);
                    commentData.setName(Name);
                    FirebaseDatabase.getInstance().getReference("ProblemsComments")
                            .child(mainId)
                            .child(Id)
                            .child(System.currentTimeMillis()+ FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue(commentData);
                }
            });

            commentsAdapter.setLoadMore(new ILoadMore() {
                @Override
                public void onLoadMore() {
                    if(items.size() < totalcomments)
                    {
                        final int[] c = {0};
                        items.add(null);
                        commentsAdapter.notifyItemInserted(items.size()-1);
                        FirebaseDatabase.getInstance().getReference("ProblemsComments")
                                .child(mainId)
                                .child(Id)
                                .orderByKey()
                                .startAt(Ids.get(Ids.size()-1))
                                .limitToFirst(11)
                                .addChildEventListener(new ChildEventListener() {
                                    @Override
                                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                        if(c[0] == 0)
                                        {
                                            items.remove(items.size()-1);
                                            commentsAdapter.notifyItemRemoved(items.size());
                                            c[0] = 1;
                                        }
                                        if (Ids.contains(snapshot.getKey()))
                                        {
                                            CommentData commentData = snapshot.getValue(CommentData.class);
                                            CommentData commentData1 = new CommentData();
                                            commentData1.setComment(commentData.getComment());
                                            commentData1.setName(commentData.getName());
                                            commentData1.setUrl(commentData.getUrl());
                                            items.add(0,commentData1);
                                            commentsAdapter.notifyDataSetChanged();
                                            commentsAdapter.setLoaded();
                                        }
                                    }

                                    @Override
                                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                    }

                                    @Override
                                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                                    }

                                    @Override
                                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });

                    }
                }
            });
        }catch (Exception e)
        {
            finish();
        }
    }

    public void LoadData()
    {
        CountProblems(new FirebaseCallback() {
            @Override
            public void onCallback(String CNT) {
                totalcomments = Integer.parseInt(CNT);
            }
        });

        FirebaseDatabase.getInstance().getReference("ProblemsComments")
                .child(mainId)
                .child(Id)
                .orderByKey()
                .limitToFirst(10)
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull final DataSnapshot snapshot, @Nullable String previousChildName) {
                        CommentData commentData = snapshot.getValue(CommentData.class);
                        CommentData commentData1 = new CommentData();
                        commentData1.setComment(commentData.getComment());
                        commentData1.setName(commentData.getName());
                        commentData1.setUrl(commentData.getUrl());
                        items.add(0,commentData1);
                        commentsAdapter.notifyDataSetChanged();
                        Ids.add(snapshot.getKey());
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private interface FirebaseCallback
    {
        void onCallback(String CNT);
    }

    private interface FirebaseCallback1
    {
        void onCallback(String name,String url);
    }

    public void NameImage(final FirebaseCallback1 firebaseCallback1)
    {
        FirebaseDatabase.getInstance().getReference("User")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        ProfileData profileData = snapshot.getValue(ProfileData.class);
                        firebaseCallback1.onCallback(profileData.getName(),profileData.getProfileurl());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void CountProblems(final FirebaseCallback firebaseCallback)
    {
        FirebaseDatabase.getInstance().getReference("Problems")
                .child(mainId)
                .child(Id)
                .child("comments")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.getValue() != null)
                        {
                            firebaseCallback.onCallback(snapshot.getValue(String.class));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        NameImage(new FirebaseCallback1() {
            @Override
            public void onCallback(String name, String url) {
                Name = name;
                Url = url;
            }
        });
    }
}
