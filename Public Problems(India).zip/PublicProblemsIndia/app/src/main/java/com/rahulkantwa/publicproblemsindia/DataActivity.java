package com.rahulkantwa.publicproblemsindia;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

import android.app.TabActivity;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.iceteck.silicompressorr.FileUtils;
import com.iceteck.silicompressorr.SiliCompressor;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DataActivity extends AppCompatActivity {
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private RelativeLayout problemslayout,progressbarlayout,bootomlayout;
    private RecyclerView problemsrecyclerview;
    private ImageView menu,add;
    private TextView name;
    private String Id = "allproblems";
    private boolean UploadProblemFlag = false,SearchFlag = false;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private List<ProblemData> problemDataList = new ArrayList<>();
    private MyAdapter myAdapter;
    private ArrayList<String> IDS = new ArrayList<>();
    private ArrayList<String> Likes = new ArrayList<>();
    private int totalproblems = 0;
    private String Types = "c";
    private String State,District,Tehsil;
    private TextView yes,no,comment;
    private ImageButton yesbutton,nobutton,commentbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);


        navigationView = (NavigationView)findViewById(R.id.naviview);
        drawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        problemslayout = (RelativeLayout)findViewById(R.id.problem_layout);
        progressbarlayout = (RelativeLayout) findViewById(R.id.progress_bar_layout_comment);
        problemsrecyclerview = (RecyclerView)findViewById(R.id.problems_recycler_view);
        menu = (ImageView)findViewById(R.id.menu);
        add = (ImageView)findViewById(R.id.add_problem);
        name = (TextView)findViewById(R.id.name_place);
        bootomlayout = (RelativeLayout)findViewById(R.id.first_line) ;
        yes = (TextView)findViewById(R.id.yes_text) ;
        no = (TextView)findViewById(R.id.no_text) ;
        comment = (TextView)findViewById(R.id.comment_text) ;
        yesbutton = (ImageButton) findViewById(R.id.thumb_up);
        nobutton = (ImageButton)findViewById(R.id.thumb_down);
        commentbutton = (ImageButton)findViewById(R.id.comment);
        final View header = navigationView.getHeaderView(0);
        final TextView headername = header.findViewById(R.id.header_username);
        TextView headermail = header.findViewById(R.id.header_mailid);
        final CircleImageView headerimage = header.findViewById(R.id.profile_header);
        try {
            headermail.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        try {
            Intent intent = getIntent();
            if (intent != null && intent.hasExtra("id"))
            {
                Id = intent.getStringExtra("id");
                Types = intent.getStringExtra("type");
                name.setText(intent.getStringExtra("name"));
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        FirebaseDatabase.getInstance().getReference("User")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        ProfileData profileData = snapshot.getValue(ProfileData.class);
                        Glide.with(header)
                                .load(Uri.parse(profileData.profileurl))
                                .into(headerimage);
                        headername.setText(profileData.getName());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


        problemsrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        LoadData(Id);
        myAdapter = new MyAdapter(problemsrecyclerview, this,problemDataList,IDS,Likes,Id);
        problemsrecyclerview.setAdapter(myAdapter);
        Leader();

        Region(new FirebaseCallback1() {
            @Override
            public void onCallback(String state, String district, String tehsil) {
                State = state;
                District = district;
                Tehsil = tehsil;
                String sss = "";
                String s = State+District;
                if(!Tehsil.equalsIgnoreCase("null"))
                {
                    s += Tehsil;
                }
                String[] ss = s.split(" ");
                for(int i = 0; i < ss.length; i++)
                {
                    sss += ss[i].trim().toLowerCase();
                }

                FirebaseDatabase.getInstance().getReference("Token")
                        .child(sss)
                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .setValue(FirebaseInstanceId.getInstance().getToken());
            }
        });



        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.LEFT);
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),AddProblem.class);
                intent.putExtra("id",Id);
                intent.putExtra("type",Types);
                startActivity(intent);
            }
        });

        myAdapter.setLoadMore(new ILoadMore() {
            @Override
            public void onLoadMore() {
                if(problemDataList.size() < totalproblems)
                {
                    final int[] c = {0};
                    problemDataList.add(null);
                    myAdapter.notifyItemInserted(problemDataList.size()-1);
                    FirebaseDatabase.getInstance().getReference("ProblemsOfUsers")
                            .child(Id)
                            .orderByKey()
                            .startAt(IDS.get(IDS.size()-1))
                            .limitToFirst(6)
                            .addChildEventListener(new ChildEventListener() {
                                @Override
                                public void onChildAdded(@NonNull final DataSnapshot snapshot, @Nullable String previousChildName) {
                                    if(c[0] == 0)
                                    {
                                       problemDataList.remove(problemDataList.size()-1);
                                       myAdapter.notifyItemRemoved(problemDataList.size());
                                       c[0] = 1;
                                    }
                                    if(!IDS.contains(snapshot.getKey()))
                                    {
                                        ProblemData problemData = snapshot.getValue(ProblemData.class);
                                        final ProblemData problemData1 = new ProblemData();
                                        problemData1.setComments(problemData.getComments());
                                        problemData1.setImageurl(problemData.getImageurl());
                                        problemData1.setLikes(problemData.getLikes());
                                        problemData1.setProblem(problemData.getProblem());
                                        problemData1.setTime(problemData.getTime());
                                        problemData1.setUserurl(problemData.getUserurl());
                                        problemData1.setUsername(problemData.getUsername());
                                        LikesProblems(snapshot.getKey(), new FirebaseCallback() {
                                            @Override
                                            public void onCallback(String CNT) {
                                                progressbarlayout.setVisibility(View.GONE);
                                                Likes.add(0,CNT);
                                                problemDataList.add(0,problemData1);
                                                IDS.add(0,snapshot.getKey());
                                                myAdapter.notifyDataSetChanged();
                                                myAdapter.setLoaded();
                                            }
                                        });
                                    }
                                }

                                @Override
                                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                                    final int position = IDS.indexOf(snapshot.getKey());
                                    ProblemData problemData = snapshot.getValue(ProblemData.class);
                                    final ProblemData problemData1 = new ProblemData();
                                    problemData1.setComments(problemData.getComments());
                                    problemData1.setImageurl(problemData.getImageurl());
                                    problemData1.setLikes(problemData.getLikes());
                                    problemData1.setProblem(problemData.getProblem());
                                    problemData1.setTime(problemData.getTime());
                                    problemData1.setUserurl(problemData.getUserurl());
                                    problemData1.setUsername(problemData.getUsername());
                                    LikesProblems(snapshot.getKey(), new FirebaseCallback() {
                                        @Override
                                        public void onCallback(String CNT) {
                                            Likes.set(position,CNT);
                                            problemDataList.set(position,problemData1);
                                        }
                                    });
                                    myAdapter.notifyDataSetChanged();
                                }

                                @Override
                                public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                                }

                                @Override
                                public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                }
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                drawerLayout.closeDrawer(Gravity.LEFT);
                if (item.getItemId() == R.id.search_location_menu)
                {
                    Intent intent = new Intent(getApplicationContext(),SearchActivity.class);
                    startActivity(intent);
                }
                if (item.getItemId() == R.id.india_menu)
                {
                    LoadData("india");
                    Id = "india";
                    Types = "c";
                    name.setText("India");
                    add.setVisibility(View.VISIBLE);
                    Leader();
                }
                if (item.getItemId() == R.id.State_location_menu)
                {
                    LoadData(State.trim().toLowerCase());
                    Id = State.trim().toLowerCase();
                    Types = "s";
                    name.setText(State);
                    add.setVisibility(View.VISIBLE);
                    Leader();
                }
                if (item.getItemId() == R.id.District_location_menu)
                {
                    String sss = "";
                    String s = State+District;
                    String[] ss = s.split(" ");
                    for(int i = 0; i < ss.length; i++)
                    {
                        sss += ss[i].trim().toLowerCase();
                    }
                    LoadData(sss);
                    Id = sss;
                    Types = "d";
                    name.setText(District);
                    add.setVisibility(View.VISIBLE);
                    Leader();
                }
                if (item.getItemId() == R.id.Tehsil_location_menu)
                {
                    if(!Tehsil.equalsIgnoreCase("null"))
                    {
                        String sss = "";
                        String s = State+District+Tehsil;
                        String[] ss = s.split(" ");
                        for(int i = 0; i < ss.length; i++)
                        {
                            sss += ss[i].trim().toLowerCase();
                        }
                        LoadData(sss);
                        Id = sss;
                        Types = "t";
                        name.setText(Tehsil);
                        add.setVisibility(View.VISIBLE);
                        Leader();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"No result found",Toast.LENGTH_LONG).show();
                    }
                }
                if (item.getItemId() == R.id.all_location_menu)
                {
                    Types = "al";
                    Id = "allproblems";
                    LoadData(Id);
                    name.setText("All Problems");
                    Leader();
                }
                return true;
            }
        });
    }

    public void Leader()
    {
        final int[] y = {0};
        final int[] n = {0};
        yesbutton.setImageResource(R.drawable.ic_thumb_up_black_24dp);
        nobutton.setImageResource(R.drawable.ic_thumb_down_black_24dp);

        FirebaseDatabase.getInstance().getReference("Yes")
                .child(Id)
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.getValue() != null)
                        {
                            yesbutton.setImageResource(R.drawable.ic_thumb_up_yes_black_24dp);
                            y[0] = 1;
                        }
                        else
                        {
                            yesbutton.setImageResource(R.drawable.ic_thumb_up_black_24dp);
                            y[0] = 0;
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        FirebaseDatabase.getInstance().getReference("No")
                .child(Id)
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.getValue() != null)
                        {
                            nobutton.setImageResource(R.drawable.ic_thumb_down_yes_black_24dp);
                            n[0] = 1;
                        }
                        else
                        {
                            nobutton.setImageResource(R.drawable.ic_thumb_down_black_24dp);
                            n[0] = 0;
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("LeaderCount")
                .child(Id);
        reference.child("Up")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.getValue() != null)
                        {
                            yes.setText(snapshot.getValue(String.class)+" Yes");
                        }
                        else
                        {
                            yes.setText("0 Yes");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
        reference.child("Down")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.getValue() != null)
                        {
                            no.setText(snapshot.getValue(String.class)+" No");
                        }
                        else
                        {
                            no.setText("0 No");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        reference.child("Comment")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.getValue() != null)
                        {
                            comment.setText(snapshot.getValue(String.class)+" Comments");
                        }
                        else
                        {
                            comment.setText("0 Comment");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        yesbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (y[0] == 0)
                {
                    yesbutton.setImageResource(R.drawable.ic_thumb_up_yes_black_24dp);
                    nobutton.setImageResource(R.drawable.ic_thumb_down_black_24dp);
                    FirebaseDatabase.getInstance().getReference("Yes")
                            .child(Id)
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue("yes")
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    yesbutton.setImageResource(R.drawable.ic_thumb_up_black_24dp);
                                    nobutton.setImageResource(R.drawable.ic_thumb_down_yes_black_24dp);
                                }
                            })
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    FirebaseDatabase.getInstance().getReference("No")
                                            .child(Id)
                                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .removeValue();
                                }
                            });
                }
                else
                {
                    FirebaseDatabase.getInstance().getReference("Yes")
                            .child(Id)
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .removeValue();
                }
            }
        });

        nobutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (n[0] == 0)
                {
                    nobutton.setImageResource(R.drawable.ic_thumb_down_yes_black_24dp);
                    yesbutton.setImageResource(R.drawable.ic_thumb_up_black_24dp);
                    FirebaseDatabase.getInstance().getReference("No")
                            .child(Id)
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue("no")
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    nobutton.setImageResource(R.drawable.ic_thumb_down_black_24dp);
                                    yesbutton.setImageResource(R.drawable.ic_thumb_up_yes_black_24dp);
                                }
                            })
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    FirebaseDatabase.getInstance().getReference("Yes")
                                            .child(Id)
                                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .removeValue();
                                }
                            });
                }
                else
                {
                    FirebaseDatabase.getInstance().getReference("No")
                            .child(Id)
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .removeValue();
                }

            }
        });

        commentbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),CommentActivity.class);
                intent.putExtra("mainId",Id);
                intent.putExtra("Id",Id);
                startActivity(intent);
            }
        });

        if(name.getText().toString().equalsIgnoreCase("All Problems"))
        {
            add.setVisibility(View.GONE);
            bootomlayout.setVisibility(View.GONE);
        }
        else
        {
            add.setVisibility(View.VISIBLE);
            bootomlayout.setVisibility(View.VISIBLE);
        }

    }



    public void LoadData(String ids)
    {
        CountProblems(ids, new FirebaseCallback() {
            @Override
            public void onCallback(String CNT) {
                totalproblems = Integer.parseInt(CNT);
            }
        });

        problemDataList.clear();
        IDS.clear();
        Likes.clear();
        problemslayout.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(),R.anim.animation));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                problemslayout.setVisibility(View.VISIBLE);
                progressbarlayout.setVisibility(View.GONE);
            }
        },950);
        FirebaseDatabase.getInstance().getReference("Problems")
                .child(ids)
                .orderByKey()
                .limitToFirst(5)
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull final DataSnapshot snapshot, @Nullable String previousChildName) {
                        ProblemData problemData = snapshot.getValue(ProblemData.class);
                        final ProblemData problemData1 = new ProblemData();
                        problemData1.setComments(problemData.getComments());
                        problemData1.setImageurl(problemData.getImageurl());
                        problemData1.setLikes(problemData.getLikes());
                        problemData1.setProblem(problemData.getProblem());
                        problemData1.setTime(problemData.getTime());
                        problemData1.setUserurl(problemData.getUserurl());
                        problemData1.setUsername(problemData.getUsername());
                        LikesProblems(snapshot.getKey(), new FirebaseCallback() {
                            @Override
                            public void onCallback(String CNT) {
                                Likes.add(0,CNT);
                                problemDataList.add(0,problemData1);
                                IDS.add(0,snapshot.getKey());
                                myAdapter.notifyDataSetChanged();
                            }
                        });
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        final int position = IDS.indexOf(snapshot.getKey());
                        ProblemData problemData = snapshot.getValue(ProblemData.class);
                        final ProblemData problemData1 = new ProblemData();
                        problemData1.setComments(problemData.getComments());
                        problemData1.setImageurl(problemData.getImageurl());
                        problemData1.setLikes(problemData.getLikes());
                        problemData1.setProblem(problemData.getProblem());
                        problemData1.setTime(problemData.getTime());
                        problemData1.setUserurl(problemData.getUserurl());
                        problemData1.setUsername(problemData.getUsername());
                        LikesProblems(snapshot.getKey(), new FirebaseCallback() {
                            @Override
                            public void onCallback(String CNT) {
                                Likes.set(position,CNT);
                                problemDataList.set(position,problemData1);
                            }
                        });
                        myAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void CountProblems(String id, final FirebaseCallback firebaseCallback)
    {
        FirebaseDatabase.getInstance().getReference("Count")
                .child(id)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String COUNT = "0";
                        if(snapshot.getValue() != null)
                        {
                            COUNT = snapshot.getValue(String.class);
                        }
                        firebaseCallback.onCallback(COUNT);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void LikesProblems(String id, final FirebaseCallback firebaseCallback)
    {
        FirebaseDatabase.getInstance().getReference("Likes")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child(id)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String s = "no";
                        if(snapshot.getValue() != null)
                        {
                            s = "yes";
                        }
                        firebaseCallback.onCallback(s);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }


    private interface FirebaseCallback
    {
        void onCallback(String CNT);
    }

    private interface FirebaseCallback1
    {
        void onCallback(String state,String district,String tehsil);
    }




    public void Region(final FirebaseCallback1 firebaseCallback1)
    {
        FirebaseDatabase.getInstance().getReference("Region")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.getValue() != null)
                        {
                            RegionData regionData = snapshot.getValue(RegionData.class);
                            firebaseCallback1.onCallback(regionData.getState(),regionData.getDistrict(),regionData.getTehsil());
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

}
