package com.rahulkantwa.publicproblemsindia;

public interface ILoadMore {
    void onLoadMore();
}
