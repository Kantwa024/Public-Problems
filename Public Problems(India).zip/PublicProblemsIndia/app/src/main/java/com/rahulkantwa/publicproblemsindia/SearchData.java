package com.rahulkantwa.publicproblemsindia;

public class SearchData {
    private String result;

    public SearchData(String result) {
        this.result = result;
    }

    public SearchData()
    {

    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
